from blackjack.cli import CLI

cli = CLI()
cli.loop()